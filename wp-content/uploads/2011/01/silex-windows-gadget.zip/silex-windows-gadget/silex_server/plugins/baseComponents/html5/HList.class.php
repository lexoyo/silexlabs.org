<?php
/*
This file is part of Silex - see http://projects.silexlabs.org/?/silex

Silex is � 2010-2011 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
class HList implements IteratorAggregate{
	public function __construct() {
		if( !php_Boot::$skip_constructor ) {
		$this->length = 0;
		;
	}}
	public $h;
	public $q;
	public $length;
	public function add($item) {
		$x = array($item, null);
		if($this->h === null) {
			$this->h =& $x;
			;
		}
		else {
			$this->q[1] =& $x;
			;
		}
		$this->q =& $x;
		$this->length++;
		unset($x);
	}
	public function push($item) {
		$x = array($item, &$this->h);
		$this->h =& $x;
		if($this->q === null) {
			$this->q =& $x;
			;
		}
		$this->length++;
		unset($x);
	}
	public function first() {
		return HList_0($this);
		;
	}
	public function last() {
		return HList_1($this);
		;
	}
	public function pop() {
		if($this->h === null) {
			return null;
			;
		}
		$x = $this->h[0];
		$this->h = $this->h[1];
		if($this->h === null) {
			$this->q = null;
			;
		}
		$this->length--;
		return $x;
		unset($x);
	}
	public function isEmpty() {
		return ($this->h === null);
		;
	}
	public function clear() {
		$this->h = null;
		$this->q = null;
		$this->length = 0;
		;
	}
	public function remove($v) {
		$prev = null;
		$l = & $this->h;
		while($l !== null) {
			if($l[0] === $v) {
				if($prev === null) {
					$this->h =& $l[1];
					;
				}
				else {
					$prev[1] =& $l[1];
					;
				}
				if($this->q === $l) {
					$this->q =& $prev;
					;
				}
				$this->length--;
				return true;
				;
			}
			$prev =& $l;
			$l =& $l[1];
			;
		}
		return false;
		unset($prev,$l);
	}
	public function iterator() {
		return new _hx_list_iterator($this);
		;
	}
	public function toString() {
		$s = "";
		$first = true;
		$l = $this->h;
		while($l !== null) {
			if($first) {
				$first = false;
				;
			}
			else {
				$s .= ", ";
				;
			}
			$s .= Std::string($l[0]);
			$l = $l[1];
			;
		}
		return ("{" . $s) . "}";
		unset($s,$l,$first);
	}
	public function join($sep) {
		$s = "";
		$first = true;
		$l = $this->h;
		while($l !== null) {
			if($first) {
				$first = false;
				;
			}
			else {
				$s .= $sep;
				;
			}
			$s .= $l[0];
			$l = $l[1];
			;
		}
		return $s;
		unset($s,$l,$first);
	}
	public function filter($f) {
		$l2 = new HList();
		$l = $this->h;
		while($l !== null) {
			$v = $l[0];
			$l = $l[1];
			if(call_user_func_array($f, array($v))) {
				$l2->add($v);
				;
			}
			unset($v);
		}
		return $l2;
		unset($l2,$l);
	}
	public function map($f) {
		$b = new HList();
		$l = $this->h;
		while($l !== null) {
			$v = $l[0];
			$l = $l[1];
			$b->add(call_user_func_array($f, array($v)));
			unset($v);
		}
		return $b;
		unset($l,$b);
	}
	public function getIterator() {
		return $this->iterator();
		;
	}
	public function __call($m, $a) {
		if(isset($this->$m) && is_callable($this->$m))
			return call_user_func_array($this->$m, $a);
		else if(isset($this->�dynamics[$m]) && is_callable($this->�dynamics[$m]))
			return call_user_func_array($this->�dynamics[$m], $a);
		else if('toString' == $m)
			return $this->__toString();
		else
			throw new HException('Unable to call �'.$m.'�');
	}
	function __toString() { return $this->toString(); }
}
;
function HList_0(&$�this) {
if($�this->h === null) {
	return null;
	;
}
else {
	return $�this->h[0];
	;
}
}
function HList_1(&$�this) {
if($�this->q === null) {
	return null;
	;
}
else {
	return $�this->q[0];
	;
}
}