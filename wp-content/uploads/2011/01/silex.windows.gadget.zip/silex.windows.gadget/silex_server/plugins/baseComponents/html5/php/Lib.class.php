<?php
/*
This file is part of Silex - see http://projects.silexlabs.org/?/silex

Silex is � 2010-2011 Silex Labs and is released under the GPL License:

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License (GPL) as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/
class php_Lib {
	public function __construct(){}
	static function hprint($v) {
		echo(Std::string($v));
		;
	}
	static function println($v) {
		php_Lib::hprint($v);
		php_Lib::hprint("\x0A");
		;
	}
	static function dump($v) {
		var_dump($v);
		;
	}
	static function serialize($v) {
		return serialize($v);
		;
	}
	static function unserialize($s) {
		return unserialize($s);
		;
	}
	static function extensionLoaded($name) {
		return extension_loaded($name);
		;
	}
	static function isCli() {
		return (0 == strncasecmp(PHP_SAPI, 'cli', 3));
		;
	}
	static function printFile($file) {
		return fpassthru(fopen($file, "r"));
		;
	}
	static function toPhpArray($a) {
		return $a->�a;
		;
	}
	static function toHaxeArray($a) {
		return new _hx_array($a);
		;
	}
	static function hashOfAssociativeArray($arr) {
		$h = new Hash();
		reset($arr); while(list($k, $v) = each($arr)) $h->set($k, $v);
		return $h;
		unset($h);
	}
	static function associativeArrayOfHash($hash) {
		return $hash->h;
		;
	}
	static function rethrow($e) {
		if(Std::is($e, _hx_qtype("php.Exception"))) {
			$__rtex__ = $e;
			throw $__rtex__;
			unset($__rtex__);
		}
		else {
			throw new HException($e);
			;
		}
		;
	}
	static function appendType($o, $path, $t) {
		$name = $path->shift();
		if($path->length === 0) {
			$o->$name = $t;
			;
		}
		else {
			$so = php_Lib_0($name, $o, $path, $t);
			php_Lib::appendType($so, $path, $t);
			$o->$name = $so;
			unset($so);
		}
		unset($name);
	}
	static function getClasses() {
		$path = null;
		$o = _hx_anonymous(array());
		reset(php_Boot::$qtypes);
		while(($path = key(php_Boot::$qtypes)) !== null) {
			php_Lib::appendType($o, _hx_explode(".", $path), php_Boot::$qtypes[$path]);
			next(php_Boot::$qtypes);
			;
		}
		return $o;
		unset($path,$o);
	}
	function __toString() { return 'php.Lib'; }
}
;
function php_Lib_0(&$name, &$o, &$path, &$t) {
if(isset($o->$name)) {
	return $o->$name;
	;
}
else {
	return _hx_anonymous(array());
	;
}
}