<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


require_once("oof_db_connection.php");
 
 class crud{
	var $connection;
	var $logger = null;
	
    function crud($loggerName){
			$this->connection = new oof_db_connection("DB - $loggerName");
			$this->logger = new logger($loggerName);
    }
    
    /**
    * getIndividualRecords
    * @access remote
    * @param form(String). name of the form from which to read the record
    * @param $ids(Array)
    */
    
    function getIndividualRecords($form, $ids){
        $this->logger->debug("getIndividualRecords, form : $form, ids :" . print_r($ids, false)); 
        try{
            $idString = $this->parseArrayToString($ids);
            $query = "SELECT * FROM ".$form." WHERE id IN (".$idString.")";
            $fromDb = $this->connection->oofSqlQuery($query);
            $retAsArray = array();
            $numRows = mysql_num_rows($fromDb);
            for($i = 0; $i < $numRows; $i++){
            array_push($retAsArray, mysql_fetch_assoc($fromDb));

            }

            return $retAsArray;
                
        }catch(Exception $e){
            $errorMessage = $e->getMessage();
            $this->logger->err("getIndividualRecords error. ".$errorMessage);
            throw new Exception("getIndividualRecords error".$errorMessage);
       }
    }
    
     /**
    * createRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
     * @param item(Array) for example {address: 'web site address', title:'boss'}
    */
    function createRecord($form, $item){
        $this->logger->debug("createRecord, form : ".$form.", item : ".print_r($item, true));
        try{
            $setString = "";
            foreach ($item as $key => $value) {
                $setString .= ", ".$key." = ";
                if(is_string($value)){
                    $setString .= "'".$value."'";
                }else{
                    $setString .= $value;
                }
            }
            //trim first ", "
            $setString = substr($setString, 2);

            $query = "INSERT INTO ".$form." SET ".$setString;
            
            $fromDb = $this->connection->oofSqlQuery($query);
            return mysql_insert_id();                
        } catch(Exception $e){
            $errorMessage = $e->getMessage();
            $this->logger->err("createRecord error. ".$errorMessage);
            throw new Exception("createRecord error".$errorMessage);
        }
    }
    
     /**
    * updateRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
    * @param item(Array)  for example {address: 'web site address', title:'boss'}
    * @param id(Integer)
    */
    function updateRecord($form, $item, $id){
        try{
            $this->logger->debug("updateRecord, form : ".$form.", item : ".print_r($item, true).", id : ".$id);
            $setString = "";
            foreach ($item as $key => $value) {
                $setString .= ", ".$key." = ";
                if(is_string($value)){
                    $setString .= "'".$value."'";
                }else{
                    $setString .= $value;
                }
            }
            //trim first ", "
            $setString = substr($setString, 2);

            $query = "UPDATE ".$form." SET ".$setString." WHERE id = ".$id;
            return $this->connection->oofSqlQuery($query);
                
        } catch(Exception $e){;
            $errorMessage = $e->getMessage();
            $this->logger->err("updateRecord error. ".$errorMessage);
            throw new Exception("updateRecord error".$errorMessage);
        }
    }
    
     /**
    * deleteRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
    * @param id(Integer)
    */
    function deleteRecord($form, $id){
       $this->logger->debug("deleteRecord, form : ".$form.", id : ".$id);
       try{

            $query = "DELETE FROM ".$form." WHERE id = ".$id;
            return $this->connection->oofSqlQuery($query);
                
        } catch(Exception $e){;
            $errorMessage = $e->getMessage();
            $this->logger->err("deleteRecord error. ".$errorMessage);
            throw new Exception("deleteRecord error".$errorMessage);
        }
    }
    
    /**getRecords
    * @access remote
    * @param form(String)
    * @param fields(Array)
    * @param whereClause(String)
    * @param orderBy(String)
    * @param count(Number)
    * @param offset(Number)
    * @returns Array
    */
    function getRecords($form, $fields, $whereClause, $orderBy, $count, $offset){
        $this->logger->debug("getRecords, form : ".$form.", fields : ".print_r($fields, true)."whereClause : ".$whereClause."orderBy : ".$orderBy."count : ".$count."offset : ".$offset); 
         $ret = false;
        try{
            $query = "SELECT ".$this->parseArrayToString($fields)." FROM ".$form;
            if(($whereClause != null) && ($whereClause != ''))
                $query = $query." WHERE ".$whereClause;
            if(($orderBy != null) && ($orderBy != ''))
                $query = $query." ORDER BY ".$orderBy;
            if(($count != null) && ($count != ''))
                $query = $query." LIMIT ".$count;
            if(($offset != null) && ($offset != ''))
                $query = $query." OFFSET ".$offset;
             $fromDb = $this->connection->oofSqlQuery($query);
             $retAsArray = array();
             $numRows = mysql_num_rows($fromDb);
             for($i = 0; $i < $numRows; $i++){
                array_push($retAsArray, mysql_fetch_assoc($fromDb));
             
             }
             
             return $retAsArray;
             
        } catch(Exception $e){;
            $errorMessage = $e->getMessage();
            $this->logger->err("getRecords error. ".$errorMessage);
            throw new Exception("getRecords error".$errorMessage);
        }

   
    }


    /**
    * private - parseArrayToString
    * @param Array in
     * @returns String. parses ["aze", "rty", "uio"] to "aze, rty, uio"
    */
    function parseArrayToString($in){
         if(($in == null)){
            return "*"; 
        }else{
            $size = sizeof($in);
            $ret = $in[0];
            
            for ($i = 1; $i < $size; $i++){ 
                $ret = $ret.", ".$in[$i];
            }      
            return $ret;            
        }
    
    }

    /**
    * private - parseStringToArray. splits, then trims
    * @param String in
     * @returns Array. parses  "aze, rty, uio" to ["aze", "rty", "uio"]
    */
    function parseStringToArray($in){
        $splitted = preg_split("/,/", $in);
        $size = sizeof($splitted);
        
        for ($i = 0; $i < $size; $i++){ 
            $splitted[$i] = trim($splitted[$i]);
        }      
        return $splitted;            
    }    
        

}


?>