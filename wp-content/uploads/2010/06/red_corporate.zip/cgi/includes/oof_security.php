<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


///////////////////////////////////
//security class for OOF
///////////////////////////////////

require_once("logger.php");

DEFINE(ALL, 1);
DEFINE(USER, 2);
DEFINE(OWNER, 3);
DEFINE(ADMIN, 4);
DEFINE(OOFSEC_LEVEL_ALL, "all");
DEFINE(OOFSEC_LEVEL_USER, "user");
DEFINE(OOFSEC_LEVEL_OWNER, "owner");
DEFINE(OOFSEC_LEVEL_ADMIN, "admin");
DEFINE(OOFSEC_ROLE_USER, "user");
DEFINE(OOFSEC_ROLE_ADMIN, "admin");
DEFINE(OOFSEC_CANALL, "canall");
DEFINE(OOFSEC_CANUPDATE, "canupdate");
DEFINE(OOFSEC_CANDELETE, "candelete");
DEFINE(OOFSEC_CANREAD, "canread");
DEFINE(OOFSEC_CANCREATE, "cancreate");

DEFINE(OOFSEC_ROLE, "role");
class  oof_security{
    var $config = null;
    var $logger = null;
   function  oof_security(){
        $this->config = parse_ini_file("../../conf/OofSecurity.ini", false);
        $this->logger = new Logger("OOF/SECURITY");
        //$this->logger->debug("config loaded : ".print_r($this->config, true));
    }
    
    function getSectionsRelatedToTable($table){
        $ret = array();
        foreach ($config as $key => $value) {
            $split = explode($config, "|");
            if($split[0] == $table){
                array_push($ret, $split[0]);
            }
        }
        return $ret;
    }

    
    function getSecurityLevel($permission, $table, $columns = null){
        do{
            $confLevel = $this->config[$table][$permission];
            if($confLevel != null)
                break;
                
            $confLevel = $this->config[$table][OOFSEC_LEVEL_CANALL];
            if($confLevel != null)
                break;

            $confLevel = $this->config[$permission];
            if($confLevel != null)
                break;

            $confLevel = $this->config[OOFSEC_LEVEL_CANALL];
            if($confLevel != null)
                break;

            $confLevel = ALL;
        
        }while(false);                
        $vardump = "permission : ".$permission.", table : ".$table.", columns : ".print_r($columns, true); 
        //$this->logger->debug($vardump);
        //$this->logger->debug("read confLevel : ".$confLevel);
        return $confLevel;
    }        
        
}



?>