<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


require_once("logger.php");
require_once("crud.php");
require_once("oof_security.php");


/** 
This adds security to the basic crud class. 
all tables must be created with at least 2 fields: id, and idOwner. id is an autoincremented counter, idUser is a reference to the User that owns the entry.
//TODO use  Authenticate::isUserInRole function
In the User table itself, it is id. 
*/
 class user_content_manager extends crud{
    var $oofSec = null;

    function user_content_manager(){
        parent::crud("user_content_manager");
        //somehow this constructor is called twice. bug in amfphp?
        $this->oofSec = new oof_security();
        
    }

    function getOwnerField($form){
        if($form == USER_TABLE){
            return "id";
        }else{
            return ID_OWNER;
        }
    }
    function getIndividualRecords($form, $ids){
        try{
            $secLevel = $this->oofSec->getSecurityLevel(OOFSEC_CANREAD, $form);
            
            $this->logger->debug("security level needed for request : ".$secLevel);
            if($secLevel >= USER){
                if(!$_SESSION[AMFPHP_ROLE]){
                    throw new Exception("permission denied, not logged in");
                    
                }
            }
            if(($secLevel == OWNER) && ($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN)){
                //check ownership of the record matches
                $idString = $this->parseArrayToString($ids);
                $query = "SELECT ".$this->getOwnerField($form)." FROM ".$form." WHERE id IN (".$idString.")";
                $fromDb = $this->connection->oofSqlQuery($query);
                $numRows = mysql_num_rows($fromDb);
                for($i = 0; $i < $numRows; $i++){
                    $row = mysql_fetch_assoc($fromDb);
                    $idRecordOwner = $row[$this->getOwnerField($form)];
                    if($idRecordOwner != $_SESSION[AMFPHP_IDUSER]){
                        throw new Exception("permission denied, not owner of record and not admin" );
                        
                    }

                }
            }
            
            if($secLevel == ADMIN){
                if($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN){ 
                    throw new Exception("permission denied, not admin");
                    
                }
            }
   
            return parent::getIndividualRecords($form, $ids);
        }catch(Exception $e){
            $this->logger->err("getIndivualRecords error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            $this->logger->debug("security level needed for request : ".$secLevel);
            throw new Exception("getIndividualRecords error");
       }
    }
    
    function createRecord($form, $item){
        try{
            $secLevel = $this->oofSec->getSecurityLevel(OOFSEC_CANCREATE, $form);
            if($secLevel >= USER){
                if(!$_SESSION[AMFPHP_ROLE]){
                    throw new Exception("permission denied, not logged in");
                    
                }
            }
            //for creation owner is the same level as user. so no owner check
            
            
            if($secLevel == ADMIN){
                if($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN){ 
                    throw new Exception("permission denied, not admin");
                    
                }
            }
            
            if($form != USER_TABLE){
                //add owner info to item
                $idOwner = $_SESSION[AMFPHP_IDUSER];
                if($idOwner){
                    $item[$this->getOwnerField($form)] = $idOwner;
                }
            }else{
                //set user
                $item[USER_ROLE] = "user";
                
            }
            return parent::createRecord($form, $item);            
            
        }catch(Exception $e){
            $this->logger->err("createRecord error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            $this->logger->debug("security level needed for request : ".$secLevel);
            throw new Exception("createRecord error");
       }        
    }
    
    function updateRecord($form, $item, $id){
        try{
            $secLevel = $this->oofSec->getSecurityLevel(OOFSEC_CANUPDATE, $form);
            if($secLevel >= USER){
                if(!$_SESSION[AMFPHP_ROLE]){
                    throw new Exception("permission denied, not logged in");
                    
                }
            }
            if(($secLevel == OWNER) && ($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN)){
                //check ownership of the record matches
                $query = "SELECT ".$this->getOwnerField($form)." FROM ".$form." WHERE id =".$id;
                $fromDb = $this->connection->oofSqlQuery($query);
                $row = mysql_fetch_assoc($fromDb);
                $idRecordOwner = $row[$this->getOwnerField($form)];
                if($idRecordOwner != $_SESSION[AMFPHP_IDUSER]){
                    throw new Exception("permission denied, not owner of record and not admin" . print_r($row, true) . "aezeze" . $idRecordOwner . "," . $_SESSION[AMFPHP_IDUSER]);
                    
                }
            }
            
            if($secLevel == ADMIN){
                if($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN){ 
                    throw new Exception("permission denied, not admin");
                    
                }
            }

            return parent::updateRecord($form, $item, $id);            
                
        }catch(Exception $e){
            $this->logger->err("updateRecord error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            throw new Exception("updateRecord error");
       }       
    }
    
   function deleteRecord($form, $id){
        try{
            $secLevel = $this->oofSec->getSecurityLevel(OOFSEC_CANDELETE, $form);
            if($secLevel >= USER){
                if(!$_SESSION[AMFPHP_ROLE]){
                    throw new Exception("permission denied, not logged in");
                    
                }
            }
            if(($secLevel == OWNER) && ($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN)){
                //check ownership of the record matches
                $query = "SELECT ".$this->getOwnerField($form)." FROM ".$form." WHERE id = ".$id;
                $fromDb = $this->connection->oofSqlQuery($query);
                $row = mysql_fetch_assoc($fromDb);
                $idRecordOwner = $row[$this->getOwnerField($form)];
                if($idRecordOwner != $_SESSION[AMFPHP_IDUSER]){
                    throw new Exception("permission denied, not owner of record and not admin");
                    
                }
            }
            
            if($secLevel == ADMIN){
                if($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN){ 
                    throw new Exception("permission denied, not admin");
                    
                }
            }
   
            return parent::deleteRecord($form, $id);
        }catch(Exception $e){
            $this->logger->err("deleteRecord error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            throw new Exception("deleteRecord error");
       }
    }
    
    function getRecords($form, $fields, $whereClause, $orderBy, $count, $offset){
        try{

            $secLevel = $this->oofSec->getSecurityLevel(OOFSEC_CANREAD, $form);
            if($secLevel >= USER){
                if(!$_SESSION[AMFPHP_ROLE]){
                    throw new Exception("permission denied, not logged in");
                    
                }
            }
            if(($secLevel == OWNER) && ($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN)){
            //don't make separate query to check ownership, just add extra condition. donwside is, no error message. to be changed?
                if(($whereClause != null) && ($whereClause != '')){
                    $whereClause = $whereClause." AND ";
                }
                $whereClause = $whereClause.$this->getOwnerField($form)." = ".$_SESSION[AMFPHP_IDUSER];
            }
            
            if($secLevel == ADMIN){
                if($_SESSION[AMFPHP_ROLE] != OOFSEC_ROLE_ADMIN){ 
                    throw new Exception("permission denied, not admin");
                    
                }
            }
             
             return parent::getRecords($form, $fields, $whereClause, $orderBy, $count, $offset);
             
        }catch(Exception $e){
            $this->logger->err("getRecords error. ".$e->getMessage());
            $this->logger->debug("session : ".print_r($_SESSION, true));
            throw new Exception("getRecords error");
       }       

   
    }

}

?>