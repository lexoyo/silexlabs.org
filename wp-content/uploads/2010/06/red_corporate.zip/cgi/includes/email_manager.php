<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


require_once("logger.php");

class email_manager{
    var $mailConfig = null;
 	var $logger = null;

  function email_manager(){
		$this->mailConfig = parse_ini_file("../../conf/OofMail.ini", true);
		$this->logger = new logger("email_web_service");
    }
    
    function getEmailsFromKeys($keys, $allowEmailAsKey){
        if($keys == ''){
            return null; //nothing serious!!
        }
        
        $keysArray = preg_split("/,/", $keys);
        
        //start by looking in Database, if configured to do so
        if($this->mailConfig["lookForKeysInDb"] == true){
			require_once("oof_db_connection.php");
            $keyTable = $this->mailConfig["keyTable"];
            $keyColumn = $this->mailConfig["keyColumn"];
            $emailColumn = $this->mailConfig["emailColumn"];
            $keys = "";
            $size = sizeof($keysArray);
            for ($i = 0; $i < $size; $i++){ 
                $keys = $keys . ", '" . $keysArray[$i] . "'";
            }
             
            //trim first ", "
            $keys = substr($keys, 2);
            
            $query = "SELECT ".$keyColumn.", ".$emailColumn." FROM ".$keyTable." WHERE ".$keyColumn." IN (".$keys.");";
            $fromDbArray = Array();
			$connection = new oof_db_connection();
            $fromDb = $connection->oofSqlQuery($query);
            if($fromDb){
                $size = mysql_num_rows($fromDb);
                for ($i = 0; $i < $size; $i++){ 
                    $row = mysql_fetch_assoc($fromDb);
                    $fromDbArray[$row[$keyColumn]] = $row[$emailColumn];
                }
            }
            $this->logger->debug("key/email pairs returned from DB : ".print_r($fromDbArray, true));
            
        }
        $emails = "";
        $size = sizeof($keysArray);
        
        //try to return an email address for each key. If key is an email address, return key(if allowed). 
        //if not, look in config.
        //finally look in results from database
        for ($i = 0; $i < $size; $i++){
            $key = $keysArray[$i];
            $matchCandidate = null;
                //is key an email address?
                if((strpos($key, "@") != false) && (strpos($key, ".") != false)){
                    if($allowEmailAsKey){
                        $matchCandidate = $key;
                    }else{
						$this->logger->debug("email as key not allowed for ".$key.". please check config.");
						throw new Exception("onkeyNotAllowed");
                        break;
                    }
            }
            
            if($matchCandidate == null){
                //look for match in config                    
                $matchCandidate = $this->mailConfig["keys"][$key];
            }
            
            if($matchCandidate == null){
                //look for match in results from DB
                $matchCandidate = $fromDbArray[$key];
            }
            
            $this->logger->debug("key : ".$key.", email : ".$matchCandidate);
            if($matchCandidate == null){
				$this->logger->debug("email for key \"".$key."\" not found.");
            }
            $emails = $emails.", ".$matchCandidate;
        }           
        
        //trim first ", "
        $emails = substr($emails, 2);
        return $emails;        
    }
    
    /**
    * sendMail
    * @@access remote
    * @param subject(String)
    * @param body(String)
    * @param fromKey(String)
    * @param toKeys(String)
    * @param ccKeys(String)
    * @param bccKeys(String)
    * @returns Boolean
    */
    function sendMail($subject, $body, $fromKey, $toKeys, $ccKeys, $bccKeys){
        $this->logger->debug("sendMail : subject : ".$subject.", body : ".$body.", fromKey : ".$fromKey.", toKeys : ".$toKeys.", ccKeys : ".$ccKeys.", bccKeys : ".$bccKeys); 
        try{
            $fromEmail = $this->getEmailsFromKeys($fromKey, $this->mailConfig["from"]["allowEmailAsKey"]);
            $toEmails = $this->getEmailsFromKeys($toKeys, $this->mailConfig["to"]["allowEmailAsKey"]);
            $ccEmails = $this->getEmailsFromKeys($ccKeys, $this->mailConfig["cc"]["allowEmailAsKey"]);
            $bccEmails = $this->getEmailsFromKeys($bccKeys, $this->mailConfig["bcc"]["allowEmailAsKey"]);
            $this->logger->debug("fromEmail : ".$fromEmail);
            $this->logger->debug("toEmails : ".$toEmails);
            $this->logger->debug("ccEmails : ".$ccEmails);
            $headers = "From : ".$fromEmail."\r\n";
            if($ccEmails != null){
                $headers .= "Cc : ".$ccEmails."\r\n";
            }
            if($bccEmails != null){
                $headers .= "Bcc : ".$bccEmails."\r\n";
            }
            $this->logger->debug("headers : ".$headers);
            if(!$error){
                $ret = mail($toEmails, $subject, $body, $headers);
            }
                        
        }catch(Exception $e){
            $this->logger->err("sendMail error. ".$e->getMessage());
            $this->logger->debug("subject : ".print_r($subject, true));
            $this->logger->debug("body : ".print_r($body, true));
            $this->logger->debug("fromKey : ".print_r($fromKey, true));
            $this->logger->debug("toKeys : ".print_r($toKeys, true));
            $this->logger->debug("ccKeys : ".print_r($ccKeys, true));
            $this->logger->debug("bccKeys : ".print_r($bccKeys, true));
            throw new Exception($e->getMessage());
		}  
        return $ret;
    
    }
    
    
}
?>