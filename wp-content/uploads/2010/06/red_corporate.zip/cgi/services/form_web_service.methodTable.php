<?php 
$this->methodTable = array(
	"getIndividualRecords" => array(
		"description" => "getIndividualRecords",
		"arguments" => array("form - (String). name of the form from which to read the record", "ids - (Array)"),
		"access" => "remote"
	),
	"createRecord" => array(
		"description" => "createRecord",
		"arguments" => array("form - (String) form. name of the form from which to read the record", "item - (Array) for example {address: \'web site address\', title:\'boss\'}"),
		"access" => "remote"
	),
	"updateRecord" => array(
		"description" => "updateRecord",
		"arguments" => array("form - (String) form. name of the form from which to read the record", "item - (Array) for example {address: \'web site address\', title:\'boss\'}", "id - (Integer)"),
		"access" => "remote"
	),
	"deleteRecord" => array(
		"description" => "deleteRecord",
		"arguments" => array("form - (String) form. name of the form from which to read the record", "id - (Integer)"),
		"access" => "remote"
	),
	"getRecords" => array(
		"description" => "getRecords",
		"arguments" => array("form - (String)", "fields - (Array)", "whereClause - (String)", "orderBy - (String)", "count - (Number)", "offset - (Number)"),
		"access" => "remote",
		"returns" => "Array"
	)
);
?>