<?php
/*
	this file is part of OOF
	OOF : Open Source Open Minded Flash Components

	OOF is (c) 2008 Alexandre Hoyau and Ariel Sommeria-Klein. It is released under the GPL License:

	This program is free software; you can redistribute it and/or
	modify it under the terms of the GNU General Public License (GPL)
	as published by the Free Software Foundation; either version 2
	of the License, or (at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	To read the license please visit http://www.gnu.org/copyleft/gpl.html
*/


require_once("../includes/account_manager.php");
//require_once(AMFPHP_BASE . "util/MethodTable.php");

//note :form and id params are required for compatibility with the API defined in the user_content_service, so that the same 
//client side components can as far as possible be used for account management 
//they are however unused here
//the two services should maybe use the same method tables, but then the user account service would expose methods
//that don't exist(yet)

 class user_account_service{
    
	//var $logger = null;
	
	function user_account_service(){
        require_once("user_account_service.methodTable.php");

        //$this->methodTable = MethodTable::create(__FILE__);		
		//$this->logger = new logger("user_account_service");
    }    

     /**
    * createRecord
    * @param form(String) form. name of the form from which to read the record
    * @param item(Array) for example {address: 'web site address', title:'boss'}
    * @access remote
    */
    function createRecord($form, $item){
//		throw new Exception("onNameTaken");
		//$this->logger->debug("create record. item : " . print_r($item, true));
		$am = new account_manager();
		return $am->createAccount($item);
    }
    
     /**
    * updateRecord
    * @access remote
    * @param form(String) form. name of the form from which to read the record
    * @param item(Array)  for example {address: 'web site address', title:'boss'}
    * @param id(Integer)
    */
    function updateRecord($form, $item, $id){
		$am = new account_manager();
		return $am->updateAccount($item);
    }
        

}


?>