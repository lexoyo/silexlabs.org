<?php 
$this->methodTable = array(
	"login" => array(
		"description" => "login",
		"arguments" => array(),
		"access" => "remote",
		"roles" => "loggedUser,admin"
	),
	"logout" => array(
		"description" => "logout",
		"arguments" => array(),
		"access" => "remote",
		"roles" => "loggedUser,admin"
	),
	"_authenticate" => array(
		"description" => "No description given.",
		"arguments" => array("name", "password"),
		"access" => "private"
	)
);
?>