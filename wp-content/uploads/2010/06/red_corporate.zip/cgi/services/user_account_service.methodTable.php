<?php 
$this->methodTable = array(
	"createRecord" => array(
		"description" => "createRecord",
		"arguments" => array("form - (String) form. name of the form from which to read the record", "item - (Array) for example {address: \'web site address\', title:\'boss\'}"),
		"access" => "remote"
	),
	"updateRecord" => array(
		"description" => "updateRecord",
		"arguments" => array("form - (String) form. name of the form from which to read the record", "item - (Array) for example {address: \'web site address\', title:\'boss\'}", "id - (Integer)"),
		"access" => "remote"
	)
);
?>