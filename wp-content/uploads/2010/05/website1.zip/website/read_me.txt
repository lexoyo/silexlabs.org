Th�me Corporate


	- Copiez collez le contenu des repertoires "contents", "media" et "fp8/ui"
	dans les repertoires correspondants de votre Silex server.

	- Facultatif : Remplacez le "loader.swf" et l'ic�ne "photograph.ico" � la racine de silex_server





Corporate Theme


	- Copy and paste the content of the "contents", "media" and "fp8/ui" folders
	into the corresponding directory of your Silex server.

	- Optional : Replace the "loader.swf" and "photograph.ico" files in the root of your Silex server.




Tema My Page plus


	- Copiar y pegar el contenido de las carpetas "content", "media" y "fp8/ui"
	en el directorio correspondiente del Silex server.

	- Optativo: Reemplazar el "loader.swf" y "photograph.ico" en la ra�z del Silex server.
