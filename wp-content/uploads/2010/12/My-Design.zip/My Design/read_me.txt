
My Design Theme


- Place the "loader.swf" file in the "loaders" file of your Silex server. And active it via the Manager > Advanced > Layouts

- Copy and paste the content of the "contents", "media"  and "layouts" folders
into the corresponding folders of your Silex server.

- Don't forget to install the excel plugin


